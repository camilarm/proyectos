<?php

echo 'editar.php?Folio=4&Tipo=Factura';//Va editar el elemento de folio 1 en mi db y lo va a escribir en el doc "editar.php"
 echo '<br>';
$folio =$_GET['Folio'];
$tipo=$_GET['Tipo'];
$fechaemision=$_GET['Fecha_emision'];
$emisor=$_GET['Emisor'];
$receptor=$_GET['Receptor'];
$detalle=$_GET['Detalle'];




include_once 'conexion.php';

//query o peticion
$sql_editar ='UPDATE facturas SET Tipo=?,Fecha_emision=?,Emisor=?,Receptor=?,Detalle=? WHERE Folio=?';//va a cambiar (set) el tipo del elemento donde (where) el folio sea igual al seteado en la url
$sentencia_editar =$pdo->prepare($sql_editar);
$sentencia_editar->execute ([$tipo,$fechaemision,$emisor,$receptor,$detalle,$folio]);

$pdo=null;
$sentencia_editar=null;

header('location:index.php')

 ?>
