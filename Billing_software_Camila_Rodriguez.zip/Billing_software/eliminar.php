<?php  //siempre se incluye la conexion pdo primero

include_once 'conexion.php';

$folio=$_GET['Folio'];//la variable folio va a recibir a traves de la URL el Folio


$sql_eliminar = 'DELETE FROM facturas WHERE Folio=?'; //query q quero q se haga, en este caso es borrar desde facturas segun un folio determinado

$sentencia_eliminar = $pdo->prepare($sql_eliminar);//la variable Folio captada a traves de la url se la mete en el where
$sentencia_eliminar->execute([$folio]); //ejecuta la sentencia

$pdo=null;
$sentencia_eliminar=null;

header('location:index.php');


?>
